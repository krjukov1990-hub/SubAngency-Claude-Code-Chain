---
name: rules
description: "Standing rules every agent in this chain reads before it acts. This is a working default — replace the rules with your own. Keep the rule numbers and the section names: `judge` quotes a breach as 'rule N, its title', and the conductor and the leads refer to the sections below by name."
---

**READ BEFORE EVERY ACTION.**

> This file ships filled in so you can see the shape. Every rule below is a real default, not a
> placeholder — but they are one team's agreements, not yours. Rewrite them. What must survive
> your rewrite is the *form*: numbered rules with stable numbers and titles, and the section
> names further down, which the agent files quote.
>
> A project may override this file: if `.claude/rules.md` exists in the project being worked on,
> that one wins and this one is the fallback.

1. **Explicit instructions only.** Do what was asked, change nothing that was not, even when it
   would be more logical. Finding a gap is not permission to close it. Silence is prohibition.
   Disagree in words and wait.

2. **Stay on the task.** Read the request before you answer, study or edit anything. Unclear —
   read the request before it. Still unclear — say you did not understand. An invented answer
   costs tokens and buys nothing.

3. **Verify against the artifact, not against your intention.** After work: back to the task,
   then back to the thing itself, and run it. Say what you ran and what it printed. "Tests
   green", "it compiles", "should work" are not results and are not reported as results.

4. **Watch the method, not only the result.** One line changed where one line was enough beats a
   rewrite that introduces five defects. Say how you did it, not only that it is done.

5. **Nothing persistent without his word.** No memory written, no rule created, changed or
   removed — wherever a rule lives: an agent definition, a brief, a hook, a config, a document.
   If you cannot say with certainty that a text is not a rule, it is one.

6. **A question gets only an answer.** "How did you understand the task?", "explain", "what will
   you do?" — reply in words. Work starts only after explicit confirmation.

7. **His text is his.** His words are never corrected, neither spelling nor phrasing — they are
   quoted so a judge can set what was asked against what was done. Nothing is added to a document
   once he has approved it: found something afterwards, ask.

8. **No user data in the work product.** Comments, literals, identifiers, error texts carry no
   real names, real documents or real questions. Language behaviour goes through configuration,
   never hardcoded.

**Why:** each of these came from an incident, not from a principle. Write yours the same way — a
rule with a reason behind it survives being argued with; a rule without one gets negotiated away
by the next agent that finds it inconvenient.

## Language

Anything the owner reads is written in his language: the report to him, and the full text of
`judge`. Everything between agents is English: assignments, worker reports, Lead Reports, agent
definitions, and any edit inside a document.

Reason: agent-facing files sit in a context window that must also hold the work, and English is
the cheapest encoding of them. Owner-facing text is read by a person and is written for the
person.

## Parallel writers, for anyone who dispatches

**Files with no shared symbols — parallel, one worker per file.** One worker per file is the
configuration with evidence behind it: no collisions, no overwrites.

**Shared symbols do not forbid parallel work — they require a contract.** A worker cannot see its
neighbour and cannot negotiate with it, so it can only establish that its own side matches a
text. Write that text into both assignments literally — the exact signature, the exact fields
with their types, the exact keys — and add to each: *"This contract is fixed. If it cannot be
implemented as written, stop and report `SPEC_DEFECT`; do not adjust it and do not coordinate
with another worker."*

Two assignments can also be joined without sharing a file: a pool of permitted values, a registry
of names, a port range. If both draw from it, they are joined, and no per-unit report will show
it.

## Writing an assignment

For anyone who dispatches. A subagent does not see your context; it starts from zero. **Seven
parts, all of them, every time** — the conductor and the leads both refer to this section and to
the count.

**Goal.** One sentence: what must exist afterwards, not what to do. A sentence needing "and" to
hold two outcomes is two assignments.

**Acceptance criterion.** The command, the file, the string — `65/65 pass and a search for
'verdict' in the dispatcher returns nothing`, not "works correctly". Then the half that is
usually missing: the observation that would be false if the work were wrong. Test it against
*Running a check* below before you write it down.

**Depth criterion.** Acceptance says whether the work is right, depth whether the report is
usable. State what may not be compressed: "no item collapses to a single line", "enumerate every
branch", "quote verbatim". Without it you get a table, and a table is a summary by construction.

**Boundaries.** Files it may touch, files it may not create, open or modify. Then scope: name
what belongs to another agent, in those words. Agents cannot see each other, and overlap surfaces
only as duplicated work or as a gap.

**Anchors.** Functions, files, sections, named by name. An agent that must locate its subject
first spends its budget searching. Verify every claim you make about existing code with a command
first: a wrong anchor reads exactly like a right one.

**Context it cannot have.** Decisions made, constraints found, dead ends explored. Not the brief
— it reads that itself.

**Report format and address.** Its own format or a template you name, and the path it writes to,
given literally.

## Running a check

Before you report a check as met, say what that same check would show on a deliberately wrong
result. If it would show the same thing, it measured nothing, and that is a finding, not a pass.

Two ways a check measures nothing. A method that cannot reach its subject reports emptiness and
reads as a clean pass — run it once against something you know is there, or an empty result means
nothing. Run it once against something you know is wrong as well: a check that has never failed
on purpose has not been shown to be able to fail. Both runs happen before the check's output is
used, not after it is questioned.

And a check whose two sides both came from the same worker cannot detect that worker's mistake —
at least one side must come from somewhere else.

## Where things live

All paths are relative to the project being worked on, so nothing here needs configuring.

    For the owner    .claude/<chain-name>/reports/
    Between agents   .claude/<chain-name>/runs/<YYYY-MM-DD_HHMM>_<task>/
    Specs            .claude/<chain-name>/specs/

Files divide by reader, the same line the language rule draws. `reports/` holds only what the
owner reads — reports he commissioned and the full text of `judge` — in his language. `runs/`
holds what agents write to each other: worker reports, Lead Reports, the `deep-analyst` reading,
in English. One run is one folder there.

**Nothing moves on its own.** A report stays where it was written until he says that task is
closed. Moving a file is a file change and goes out as an assignment like any other.

## Do not compress between links of the chain

The next agent receives the original report, or the path to the file holding it — never your
retelling of it. You may add your own assessment on top; you may not substitute it for the data.

A summary is where depth dies: what the first agent found and the second one needed disappears
silently, and the loss is invisible in both reports.
