# Ledger — brief for subagents

> **This is a filled example on a project that does not exist.** It ships this way so you can see
> the form before you write your own. Replace all of it. What must survive is the section list
> below: the agent files promise their workers that layout, invariants, traps, build order and
> platform specifics live here.
>
> A project may override this file: if `.claude/PROJECT-BRIEF.md` exists in the project being
> worked on, that one wins and this one is the fallback.

The project's own rules, on top of the standing rules in `rules.md`. Where the two speak of the
same thing, this file is the narrower and it wins for work inside this project.

    Project        the repository you were dispatched on
    Architecture   docs/architecture.md — the target state, revision 4

The architecture document marks each component `APPROVED`, `REWRITE` or `WITHDRAWN`, and that
mark decides how a divergence is read: an approved component diverging from the document is a
defect, one marked for rewrite diverging from it is expected.

## What it is

A billing API. TypeScript on Node, Postgres behind it, one worker process for scheduled runs.
A request arrives over HTTP, is validated at the edge, and every write goes through the ledger
module so that no balance is ever computed twice from different code.

```
client ──HTTP──▶ api/       ──▶ ledger/      ──▶ Postgres
                 (validation,     (the only        (append-only
                  no business      writer of        entries table)
                  logic)           balances)
```

## Layout

    src/
      api/            routes and request validation — no business logic lives here
      ledger/         the only module permitted to write balance entries
      jobs/           scheduled work; each job is idempotent by contract
      db/             migrations and the query layer; migrations are append-only
      shared/         types used by more than one module — the source of truth for them
    test/
      unit/           per-module
      contract/       API shape; these are the tests that break on an interface change
    docs/
      architecture.md the target state — paths at the top of this file

## Invariants

Violating one of these is critical, not stylistic.

1. **One writer.** Balances are written only by `ledger/`. A second writer cannot be reviewed
   into safety; it has to not exist. A write found anywhere else is a defect regardless of how
   correct it looks.

2. **Entries are append-only.** No update, no delete, no correction in place. A mistake is fixed
   by a compensating entry, so the history stays readable backwards.

3. **Jobs are idempotent.** Every job may run twice — the scheduler guarantees at-least-once, not
   exactly-once. A job that is only correct on the first run is a defect that shows up in
   production and never in tests.

4. **The edge validates, the core assumes.** `api/` rejects malformed input; `ledger/` is written
   as if input is already valid. Duplicating the check inside the core is how the two drift apart.

5. **No user data in code, fixtures or tests.** Real customer names, real invoice numbers and real
   amounts do not enter the repository, not even in a test.

## Traps

The mechanisms that silently undo an edit. Each is named by symbol, never by line number — a line
number goes stale on the first edit above it, and a wrong anchor reads exactly like a right one.

- **`applyMigrations` runs on every start and compares checksums.** Edit a migration that has
  already run and the checksum no longer matches: the process refuses to start with an error that
  names the file but not the reason. Migrations are append-only for this reason and no other.

- **`config/defaults.ts` is compiled in, `config/local.json` is read at runtime.** A value changed
  only in the compiled defaults appears to take effect in tests and does nothing in a running
  process, because the runtime file shadows it. Change both or neither.

- **The query layer caches prepared statements by SQL text.** Change a query's shape and the old
  plan is still used for the life of the process. A performance change measured without a restart
  measured nothing.

## Build and test

    npm run build            typecheck and emit
    npm test                 unit and contract tests
    npm run test:contract    the contract suite alone, when the change is at the API edge

**Never run `npm run db:reset` on a machine that has data.** It drops and recreates the schema
without asking. There is no confirmation prompt and no backup step.

Count PASS and FAIL, not the exit code: the contract runner prints `FAIL` per case and still
exits zero when the suite is invoked through `npm`.

## Backup rule

Before editing any existing file, copy it beside itself as `<name>.orig-<YYYY-MM-DD_HHMM>`. No
copy, no edit — the copies are what show afterwards which files an agent actually touched, and
whether it touched any it was not permitted to.

A file created in the current assignment needs no copy: there is no original to archive.

The copies are deleted only on the owner's explicit word with an explicit file list, never on an
agent's own judgement.

## Platform specifics

- A failed write that reports a lock is retried, not reported as a defect — and not routed around
  by writing somewhere else.
- **Never suppress the error stream of a build or test command.** Success and failure are read
  from the exit code and from nothing else, and suppression corrupts it.
- Paths in this project are written with forward slashes and resolved relative to the repository
  root, on every platform.

## Verifying the result

Rule 3 in `rules.md`, *Verify against the artifact, not against your intention*, sets the
standard. Here it means: a change to `ledger/` is proved by a contract test that fails before it
and passes after, quoted with its output — not by the unit test that was written alongside the
change and shares its assumptions.
